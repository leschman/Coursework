/**
* Logan Esch
* CSCI 112 
* Lab 04
* input file
*/

//preprocessor directives.
#include <stdio.h>
#include <stdlib.h>

//input function.
int input(){
	int temp;
	printf("Please enter an integer: ");
	scanf("%d", &temp);
	printf("\n");
	return temp;
}
