/**
* Logan Esch
* CSCI 112
* Lab 4
* main.c
*/
//preprocessor directives
#include <stdio.h>
#include <stdlib.h>

//function prototypes
void problem_1();
void problem_2();
void problem_3();
void problem_4();
void problem_5();
void problem_6();
int input();

//main function
int
main(){
	problem_1();
	problem_2();
	problem_3();
	problem_4();
	problem_5();
	problem_6();
	return (0);
}

//problem 1
void problem_1(){
	int a,b;
	a = input();
	b = input();
	if(a != 0 && b == 0){
		printf("X \n.");
	}else{
		printf("Y \n.");
	}
}

//problem 2
void problem_2(){
	int a,b;
	a = input();
	b = input();
	if(a == 0 && b == 0){
		printf("Y \n.");
	}else{
		printf("X \n.");
	}
}

//problem 3
void problem_3(){
	int a,b;
	a = input();
	b = input();
	if(a != 0 || b != 0){
		printf("X \n.");
	}else{
		printf("Y \n.");
	}
}

//problem 4
void problem_4(){
	int a = input();
	switch(a){
	case 0 :
	case 1 :
	case 2 :
	case 3 :
		printf("too low\n");
		break;
	case 4 :
	case 5 :
		printf("just right\n");
		break;
	case 6 :
	case 7 :
	case 8 :
	case 9 :
		printf("too high\n");
		break;
	default :
		printf("Sorry, 0-9 is all I can do.");
	}
}

//problem 5
void problem_5(){
	int a, b;
	a = input();
	b = input();
	if(a && b  || !a && !b){
		printf("X. \n");
	}else{
		printf("Y. \n");
	}
}

//problem 6
void problem_6(){
	float x = 1.1;
	if(x == (float)1.1) {
	printf("this should print\n");
	}
}
